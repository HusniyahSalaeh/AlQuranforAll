# EduCartoon Storefront (Next.js + Tailwind)
เว็บไซต์พร้อมใช้สำหรับขายใบงาน/คอร์สออนไลน์/หนังสือการ์ตูน

## ใช้งานเร็ว
```bash
npm install
npm run dev
# เปิด http://localhost:3000
```

## Deploy บน Vercel
- สร้าง repo ใน GitHub แล้ว push โค้ดนี้ขึ้นไป
- เข้า vercel.com -> New Project -> เลือก repo -> Deploy

## ปรับข้อมูลสินค้า
แก้ที่ตัวแปร `CATALOG` และ `SITE` ใน `app/page.tsx`
